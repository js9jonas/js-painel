import { NextRequest, NextResponse } from "next/server";
import { pool } from "@/lib/db";

export async function PUT(
  req: NextRequest,
  ctx: { params: Promise<{ id: string }> }
) {
  try {
    const { id: rawId } = await ctx.params;
    const idCliente = String(rawId).trim();

    const body = await req.json().catch(() => ({}));
    const observacao =
      typeof body?.observacao === "string" ? body.observacao.trim() : null;

    const result = await pool.query(
      `
      UPDATE public.clientes
      SET observacao = $2
      WHERE id_cliente = $1::bigint
      RETURNING id_cliente::text AS id_cliente, observacao;
      `,
      [idCliente, observacao]
    );

    if (result.rowCount === 0) {
      return NextResponse.json(
        { ok: false, error: `Cliente ${idCliente} não encontrado` },
        { status: 404 }
      );
    }

    return NextResponse.json({ ok: true, cliente: result.rows[0] });
  } catch (err: any) {
    console.error("Erro ao salvar observação:", err);
    return NextResponse.json(
      { ok: false, error: err?.message ?? "Erro interno" },
      { status: 500 }
    );
  }
}
